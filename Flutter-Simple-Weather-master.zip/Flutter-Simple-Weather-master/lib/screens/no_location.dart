import 'package:flutter/material.dart';

// Implement a widget in case location was not found.
